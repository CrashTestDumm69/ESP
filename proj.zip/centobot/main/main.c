#include "main.h"

#define TAG "MAIN"

static float val1 = 0.f;
static float val2 = 0.f;

static int arg = 0;
static int ind = 0;

static char cmd;

static char arg1[12];
static char arg2[12];

static robot_mode mode = SLEEP;

static bool near_dock = true;

static esp_err_t jtag_init()
{
    esp_err_t ret;

    setvbuf(stdin, NULL, _IONBF, 0);

    esp_vfs_dev_usb_serial_jtag_set_rx_line_endings(ESP_LINE_ENDINGS_CR);
    esp_vfs_dev_usb_serial_jtag_set_tx_line_endings(ESP_LINE_ENDINGS_CRLF);

    fcntl(fileno(stdout), F_SETFL, 0);
    fcntl(fileno(stdin), F_SETFL, 0);

    usb_serial_jtag_driver_config_t cfg = {
        .rx_buffer_size = 1024,
        .tx_buffer_size = 1024,
    };

    ret = usb_serial_jtag_driver_install(&cfg);
    esp_vfs_usb_serial_jtag_use_driver();

    return ret;
}

static void select_mode(robot_mode sel)
{
    mode = sel;
}

static void run_command()
{
    val1 = strtof(arg1, NULL);
    val2 = strtof(arg2, NULL);

    switch(cmd) 
    {
        case READ_MOTORS:
            printf("%f %f %f %f\n", get_left_motor_dist(), get_left_motor_vel(), get_right_motor_dist(), get_right_motor_vel());
            break;

        case SET_ROBOT_VELOCITY:
            move_robot(val1, val2);
            break;

        case READ_IMU:
            printf("%f %f %f\n", get_gyro_z(), get_accel_x(), get_accel_y());
            break;

        case READ_ODOMETRY:
            printf("%f %f %f %f %f\n", get_odom_x(), get_odom_y(), get_odom_theta(), get_linear_vel(), get_angular_vel());
            break;

        case RESET_VALUES:
            reset_values();
            break;

        case READ_ULTRASONIC_SENSORS:
            printf("%f %f %f\n", get_front_distance(), get_left_distance(), get_right_distance());
            break;

        case READ_VOLTAGE_SENSOR:
            printf("%f\n", get_bus_voltage());
            break;

        case READ_CLIFF_SENSOR:
            printf("%f\n", get_cliff_distance());
            break;

        case SELECT_ROBOT_MODE:
            select_mode((int)val1);
            break;

        case NEAR_DOCK:
            near_dock = true;
            break;
        
        case FAR_DOCK:
            near_dock = false;
            break;

        case SELECT_ROBOT_STATE:
            select_status((int)val1);
            break;

        case SET_BRAKES:
            set_brakes();
            break;

        default:
            break;
    }
}

static void reset_command()
{
    cmd = END;
    for(int i = 0; i < 12; i++)
    {
        arg1[i] = arg2[i] = 0;
    }
    val1 = 0;
    val2 = 0;
    arg = 0;
    ind = 0;
}

static void read_task(void)
{
    char c;
    while(1)
    {
        scanf("%c", &c);
        if(c == 13 || c == 10)
        {
            switch(arg)
            {
                case 1:
                    arg1[ind] = END;
                    break;
                
                case 2:
                    arg2[ind] = END;
                    break;
                
                default:
                    break;
            }
            run_command();
            reset_command();
        }
        else if(c == ' ')
        {
            switch(arg)
            {
                case 0:
                    arg = 1;
                    break;
                
                case 1:
                    arg1[ind] = END;
                    arg = 2;
                    ind = 0;
                    break;
                
                default:
                    break;
            }
        }
        else
        {
            switch(arg)
            {
                case 0:
                    cmd = c;
                    break;

                case 1:
                    arg1[ind] = c;
                    ind++;
                    break;

                case 2:
                    arg2[ind] = c;
                    ind++;
                    break;

                default:
                    break;
            }
        }
    }
}

static void multiplex(void)
{
    while(1)
    {
        read_front_distance();
        if(near_dock)
        {
            switch_multiplexer(CHARGER);
            search_dock();
            switch_multiplexer(ULTRASONIC);
        }
    }
}

static void read_i2c_sensors(void)
{
    while(1)
    {    
        read_bus_voltage();
        // read_mpu9250_data();
        read_left_distance();
        read_right_distance();
        read_cliff_distance();
        vTaskDelay(pdMS_TO_TICKS(50));
    }
}

void app_main(void)
{
    jtag_init();
    status_led_init();
    i2c_master_init();
    ina219_init();
    mpu9250_init();
    unit_sonic_i2c_init();
    vl53l0x_init();
    multiplexer_init();
    uart_init();
    a022yuw_init();
    charging_init();
    motor_control_init();    

    // line_follower_init();
    xTaskCreate(read_task, "read_task", 4096, NULL, configMAX_PRIORITIES, NULL);
    xTaskCreate(read_i2c_sensors, "read_i2c_sensors_task", 4096, NULL, configMAX_PRIORITIES, NULL);
    xTaskCreate(multiplex, "multiplex", 4096, NULL, configMAX_PRIORITIES, NULL);
}
