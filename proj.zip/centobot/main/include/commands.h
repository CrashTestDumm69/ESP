#ifndef COMMANDS_H_
#define COMMANDS_H_

#define READ_MOTORS                 'r'
#define SET_ROBOT_VELOCITY          's'
#define READ_IMU                    'i'
#define READ_ODOMETRY               'o'
#define RESET_VALUES                'n'
#define READ_ULTRASONIC_SENSORS     'u'
#define READ_VOLTAGE_SENSOR         'v'
#define READ_CLIFF_SENSOR           'f'
#define SELECT_ROBOT_MODE           'm'
#define NEAR_DOCK                   'd'
#define FAR_DOCK                    'D'
#define SELECT_ROBOT_STATE          't'
#define SET_BRAKES                  'b'

#endif //COMMANDS_H_