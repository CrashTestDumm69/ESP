#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "led_strip.h"

#include "driver/usb_serial_jtag.h"
#include "esp_vfs_usb_serial_jtag.h"
#include "esp_vfs_dev.h"

#include "i2c_sensor.h"
#include "ina219.h"
#include "motor_control.h"
#include "mpu9250.h"
#include "vl53l0x.h"
#include "a02yyuw.h"
#include "unit_sonic.h"
#include "status_led.h"
#include "line_follower.h"
#include "uart_multiplexer.h"
#include "charging.h"
#include "commands.h"

#define END '\0'

typedef enum robot_modes_e
{
    SLEEP,
    LINE_FOLLOWER,
    AUTO_NAVIGATION,
    MODE_MAX
}robot_mode;

#endif // MAIN_H_