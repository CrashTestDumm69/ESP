#include "a02yyuw.h"

#define TAG "Ultrasonic"

static float distance = 0.f;

static bool stop_flag = false;

float get_front_distance()
{
    return distance;
}

void read_front_distance()
{
    unsigned char data[5] = {};
    uart_read_bytes(UART_NUM_1, data, 5, pdMS_TO_TICKS(100));
    if(data[4] == 0xFF)
    {
        uart_flush(UART_NUM_1);

        if(data[0] == 0xFF)
        {
            int sum;
            sum = (data[0] + data[1] + data[2]) & 0x00FF;
            if(sum == data[3])
            {
                distance = (data[1] << 8) + data[2];
            }
            else
            {
                ESP_LOGE(TAG,"ERROR");
            }
        }
    }
}

esp_err_t a022yuw_init(void)
{
    return ESP_OK;
}