#ifndef A022YUW_H_
#define A022YUW_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "uart_multiplexer.h"

esp_err_t a022yuw_init(void);

void read_front_distance();

float get_front_distance();

#endif //A022YUW_H_