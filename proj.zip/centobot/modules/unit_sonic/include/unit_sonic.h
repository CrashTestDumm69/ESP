#ifndef UNIT_SONIC_I2C_H_
#define UNIT_SONIC_I2C_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_err.h"
#include "esp_log.h"

#include "i2c_sensor.h"

#define UNIT_SONIC_ADDR     0x57
#define TCAADDR             0x70

typedef enum i2c_devices_e
{
    LEFT_ULTRASONIC = 0x06,
    RIGHT_ULTRASONIC,
    I2C_DEVICES_MAX
}i2c_devices;

float get_left_distance();

float get_right_distance();

void read_left_distance();

void read_right_distance();

esp_err_t unit_sonic_i2c_init(void);

#endif //UNIT_SONIC_I2C_H_