#include "unit_sonic.h"

#define TAG "Unit Sonic"

static float left_distance = 0.f;
static float right_distance = 0.f;

const static uint8_t x1 = 0x01;

float get_left_distance()
{
    return left_distance;
}

float get_right_distance()
{
    return right_distance;
}

void read_left_distance()
{
    uint8_t buffer[3];

    uint8_t d = (1 << LEFT_ULTRASONIC);

    i2c_master_device_write(TCAADDR, &d, 1);
    i2c_master_device_write(UNIT_SONIC_ADDR, &x1, 1);
    vTaskDelay(pdMS_TO_TICKS(120));
    i2c_master_device_read(UNIT_SONIC_ADDR, buffer, 3);
    
    uint32_t data = buffer[0];
    data <<= 8;
    data |= buffer[1];
    data <<= 8;
    data |= buffer[2];

    left_distance = data / 1000;
    if(left_distance > 4500)
    {
        left_distance = 4500.f;
    }
}

void read_right_distance()
{
    uint8_t buffer[3];

    uint8_t d = (1 << RIGHT_ULTRASONIC);

    i2c_master_device_write(TCAADDR, &d, 1);
    i2c_master_device_write(UNIT_SONIC_ADDR, &x1, 1);
    vTaskDelay(pdMS_TO_TICKS(120));
    i2c_master_device_read(UNIT_SONIC_ADDR, buffer, 3);
    
    uint32_t data = buffer[0];
    data <<= 8;
    data |= buffer[1];
    data <<= 8;
    data |= buffer[2];

    right_distance = data / 1000;
    if(right_distance > 4500)
    {
        right_distance = 4500.f;
    }
}

esp_err_t unit_sonic_i2c_init(void)
{
    return ESP_OK;
}