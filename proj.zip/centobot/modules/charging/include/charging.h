#ifndef CHARGING_H_
#define CHARGING_H_

#pragma once

#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "driver/uart.h"
#include "esp_log.h"

#include "status_led.h"
#include "uart_multiplexer.h"

#define RX_BUF_SIZE 10

void search_dock();

esp_err_t charging_init(void);

#endif //CHARGING_H_