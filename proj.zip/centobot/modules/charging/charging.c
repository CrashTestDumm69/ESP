#include "charging.h"

#define TAG "Charger"

void search_dock()
{
    uint8_t data[RX_BUF_SIZE + 1];
    int rxBytes = uart_read_bytes(UART_NUM_1, data, RX_BUF_SIZE, pdMS_TO_TICKS(100));
    data[rxBytes] = 0;
    if(strcmp((const char*)data,"dock") == true)
    {
        uart_write_bytes(UART_NUM_1, "docked", sizeof("docked"));
        select_status(CHARGING);
        gpio_set_level(GPIO_NUM_10,1);
        while(strcmp((const char*)data,"dock") == true)
        {
            rxBytes = uart_read_bytes(UART_NUM_1, data, RX_BUF_SIZE, pdMS_TO_TICKS(100));
            data[rxBytes] = 0;
        }
    }
    select_status(IDLE);
    gpio_set_level(GPIO_NUM_10,0);
}

esp_err_t charging_init(void)
{
    esp_rom_gpio_pad_select_gpio(GPIO_NUM_10);
    gpio_set_direction(GPIO_NUM_10, GPIO_MODE_OUTPUT);
    gpio_set_level(GPIO_NUM_10, 0);
    return ESP_OK;
}