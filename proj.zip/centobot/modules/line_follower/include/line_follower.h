#ifndef LINE_FOLLOWER_H_
#define LINE_FOLLOWER_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "esp_adc/adc_oneshot.h"
#include "esp_adc/adc_cali.h"
#include "esp_adc/adc_cali_scheme.h"

#define NUM_SENSORS     5

#define PIN1            ADC_CHANNEL_3
#define PIN2            ADC_CHANNEL_4
#define PIN3            ADC_CHANNEL_5
#define PIN4            ADC_CHANNEL_6
#define PIN5            ADC_CHANNEL_7

void line_follower_init(void);

#endif // LINE_FOLLOWER_H_