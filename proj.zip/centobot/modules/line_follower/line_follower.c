#include "line_follower.h"

#define TAG "Line follower"

static const adc_channel_t sensors[NUM_SENSORS] = {PIN1, PIN2, PIN3, PIN4, PIN5};
static int sensor_values[NUM_SENSORS];

static adc_oneshot_unit_handle_t adc1_handle;
static adc_oneshot_unit_init_cfg_t init_config1 = {
    .unit_id = ADC_UNIT_1,
    .ulp_mode = ADC_ULP_MODE_DISABLE,
};
static const adc_cali_curve_fitting_config_t cali_config = {
    .unit_id = ADC_UNIT_1,
    .atten = ADC_ATTEN_DB_11,
    .bitwidth = ADC_BITWIDTH_DEFAULT,
};

static adc_cali_handle_t pin_handle[NUM_SENSORS] = {NULL, NULL, NULL, NULL, NULL};
static adc_cali_curve_fitting_config_t pin_config[NUM_SENSORS];

static void read_task()
{
    int i;
    while(1)
    {
        for(i = 0; i < NUM_SENSORS; i++)
        {
            adc_oneshot_read(adc1_handle, sensors[i], &sensor_values[i]);
            adc_cali_raw_to_voltage(pin_handle[i], sensor_values[i], &sensor_values[i]);
            printf("%d ", sensor_values[i]);
        }
        printf("\n");
        vTaskDelay(5);
    }
}

void line_follower_init(void)
{
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config1, &adc1_handle));

    adc_oneshot_chan_cfg_t config = {
        .bitwidth = ADC_BITWIDTH_DEFAULT,
        .atten = ADC_ATTEN_DB_11,
    };

    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc1_handle, ADC_CHANNEL_3, &config));
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc1_handle, ADC_CHANNEL_4, &config));
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc1_handle, ADC_CHANNEL_5, &config));
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc1_handle, ADC_CHANNEL_6, &config));
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc1_handle, ADC_CHANNEL_7, &config));

    for(int i = 0; i < 5; i++)
    {
        pin_config[i] = cali_config;
        pin_config[i].chan = sensors[i];
        ESP_ERROR_CHECK(adc_cali_create_scheme_curve_fitting(&pin_config[i], &pin_handle[i]));
    }

    xTaskCreate(read_task, "read_task", 4096, NULL, 5, NULL);
    
}