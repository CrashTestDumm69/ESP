#include "motor_control.h"

#define TAG "motor_control"

static struct motor left_motor_data = {0,0};
static struct motor right_motor_data = {0,0};

static float left_motor_dist = 0.f;
static float right_motor_dist = 0.f;
static float left_motor_vel = 0.f;
static float right_motor_vel = 0.f;
static float left_motor_pos = 0.f;
static float right_motor_pos = 0.f;

static float left_wheel_old_pos;
static float right_wheel_old_pos;

static float odom_x = 0.f;
static float odom_y = 0.f;
static float odom_theta = 0.f;
static float linear = 0.f;
static float angular = 0.f;

static unsigned char stop = 'n';

static int left_cmd;
static int right_cmd;

static int64_t timer;

static uint8_t count = 0;

static uint8_t calc_crc8(uint8_t *data)
{
    uint8_t crc = 0x00;
    uint8_t inbyte, mix;
    for(int i = 0;i < 9;i++)
    { 
        inbyte = data[i];
        for(int j = 0;j < 8;j++)
        {
            mix = (crc ^ inbyte) & 0x01;
            crc = crc >> 1;
            if(mix)
            {
                crc = crc ^ 0x8C;
            }
            inbyte = inbyte >> 1;
        } 
    }
    return crc;
}

static int64_t map(int64_t x, int64_t in_min, int64_t in_max, int64_t out_min, int64_t out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

static void get_val(uint8_t id)
{
    uint8_t data[10] = {id, 0x74, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    data[9] = calc_crc8(data);
    uint8_t read_data[10];
    const int tbytes = uart_write_bytes(UART_NUM_0, data, 10);
    if(tbytes != 10)
    {
        ESP_LOGE(TAG, "Couldn't send read command to %d", id);
        return;
    }
    const int rbytes = uart_read_bytes(UART_NUM_0, read_data, 10, pdMS_TO_TICKS(10));
    if(rbytes == 10 && read_data[9] == calc_crc8(read_data))
    {
        switch(read_data[0])
        {
            case 0x01:
                left_motor_data.vel = (read_data[4] << 8) | read_data[5];

                if(left_motor_data.vel & 0x8000)
                {
                    left_motor_data.vel = -((left_motor_data.vel ^ 0xFFFF) + 1);
                }

                if(data[1] == 0x74)
                {
                    left_motor_data.pos = map(read_data[7],0,255,0,359);
                }

                break;

            case 0x02:
                right_motor_data.vel = (read_data[4] << 8) | read_data[5];

                if(right_motor_data.vel & 0x8000)
                {
                    right_motor_data.vel = -((right_motor_data.vel ^ 0xFFFF) + 1);
                }

                if(data[1] == 0x74)
                {
                    right_motor_data.pos = map(read_data[7],0,255,0,359);
                }

                break;

            default:
                break;
        }
    }
}

static void read_motor_values()
{
    int delta_angle;

    get_val(0x01);

    left_motor_vel = left_motor_data.vel * 0.10472;
  
    delta_angle = (360 - left_motor_data.pos) - left_motor_pos;
    if (delta_angle < -180.0) 
    {
        delta_angle += 360.0;
    } 
    else if (delta_angle > 180.0) 
    {
        delta_angle -= 360.0;
    }
    
    left_motor_dist += delta_angle * P180;
    left_motor_pos = 360 - left_motor_data.pos;
    
    get_val(0x02);
    
    right_motor_vel = -1 * right_motor_data.vel * 0.10472;
    
    delta_angle = right_motor_data.pos - right_motor_pos;
    if (delta_angle < -180.0) 
    {
        delta_angle += 360.0;
    } 
    else if (delta_angle > 180.0) 
    {
        delta_angle -= 360.0;
    }
    
    right_motor_dist += delta_angle * P180;
    right_motor_pos = right_motor_data.pos;
}

static void calc_odom()
{
    const double left_wheel_cur_pos = left_motor_dist * RADIUS;
    const double right_wheel_cur_pos = right_motor_dist * RADIUS;

    // Estimate velocity of wheels using old and current position:
    const double left_wheel_est_vel = left_wheel_cur_pos - left_wheel_old_pos;
    const double right_wheel_est_vel = right_wheel_cur_pos - right_wheel_old_pos;

    // Update old position with current:
    left_wheel_old_pos = left_wheel_cur_pos;
    right_wheel_old_pos = right_wheel_cur_pos;

    const double dt = (esp_timer_get_time() - timer) / 1000000.0;
    timer = esp_timer_get_time();
    // Compute linear and angular diff:
    const double linear_ = (left_wheel_est_vel + right_wheel_est_vel) * 0.5;
    // Now there is a bug about scout angular velocity
    const double angular_ = (right_wheel_est_vel - left_wheel_est_vel) / WHEELBASE;

    if(fabs(angular_) < 0.000001)
    {
        const double direction = odom_theta + angular_ * 0.5;
        
        /// Runge-Kutta 2nd order integration:
        odom_x += linear_ * cos(direction);
        odom_y += linear_ * sin(direction);
        odom_theta += angular_;
    }
    else
    {
        /// Exact integration (should solve problems when angular is zero):
        const double odom_theta_old = odom_theta;
        const double r = linear_ / angular_;
        odom_theta += angular_;
        odom_x += r * (sin(odom_theta) - sin(odom_theta_old));
        odom_y += -r * (cos(odom_theta) - cos(odom_theta_old));
    }
    linear = linear_ / dt;
    angular = angular_ / dt;
}

void set_vel(uint8_t id, int vel, uint8_t acc)
{
    uint8_t data[10] = {id, 0x64, (uint8_t)(vel >> 8), (uint8_t)(vel & 0xFF), 0x00, 0x00, acc, 0x00, 0x00, 0x00};
    data[9] = calc_crc8(data);
    if(vel == 0)
    {
        data[3] = 0x01;
        uart_write_bytes(UART_NUM_0, data, 10);
        uart_read_bytes(UART_NUM_0, data, 10, pdMS_TO_TICKS(10));
        vTaskDelay(pdMS_TO_TICKS(100));
        data[3] = 0x00;
    }
    uart_write_bytes(UART_NUM_0, data, 10);
    uart_read_bytes(UART_NUM_0, data, 10, pdMS_TO_TICKS(10));
}

void set_brakes()
{
    uint8_t data[10] = {0x01, 0x64, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00};
    uart_write_bytes(UART_NUM_0, data, 10);
    uart_read_bytes(UART_NUM_0, data, 10, pdMS_TO_TICKS(10));
    data[0] = 0x02;
    uart_write_bytes(UART_NUM_0, data, 10);
    uart_read_bytes(UART_NUM_0, data, 10, pdMS_TO_TICKS(10));
}

void move_robot(float lin_v, float ang_v)
{
    if(stop == 'y')
    {
        left_cmd = right_cmd = 0;
    }
    else
    {    
        if(ang_v == 0)
        {
            left_cmd = right_cmd = (lin_v / RADIUS) * 9.5493;
        }
        else
        {
            left_cmd = ((lin_v - (WHEELBASE * ang_v / 2)) / RADIUS) * 9.5493;
            right_cmd = ((lin_v + (WHEELBASE * ang_v / 2)) / RADIUS) * 9.5493;
        }
        right_cmd = -1 * right_cmd;
    }
    count = 0;
    set_vel(2, right_cmd, 3);
    set_vel(1, left_cmd, 3);
}

void set_motor_id(uint8_t id)
{
    uint8_t data[10] = {0xAA, 0x55, 0x53, id, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    for(int i = 0;i < 5;i++)
    {
        const int tbytes = uart_write_bytes(UART_NUM_0, data, 10);
        if(tbytes != 10)
        {
            ESP_LOGE(TAG, "Couldn't set motor id");
        }
    }
}

float get_left_motor_dist()
{
    return left_motor_dist;
}

float get_right_motor_dist()
{
    return right_motor_dist;
}

float get_left_motor_vel()
{
    return left_motor_vel;
}

float get_right_motor_vel()
{
    return right_motor_vel;
}

float get_odom_x()
{
    return odom_x;
}

float get_odom_y()
{
    return odom_y;
}

float get_odom_theta()
{
    return odom_theta;
}

float get_linear_vel()
{
    return linear;
}

float get_angular_vel()
{
    return angular;
}

void reset_values()
{
  left_motor_dist = right_motor_dist = 0;
  get_val(0x01);
  left_motor_pos = 360 - left_motor_data.pos;
  get_val(0x02);
  right_motor_pos = right_motor_data.pos;
  odom_x = odom_y = odom_theta = 0.f;
  timer = esp_timer_get_time();
  left_wheel_old_pos = 0.f;
  right_wheel_old_pos = 0.f;
  linear = 0.f;
  angular = 0.f;
}

void set_stop_flag()
{
    stop = 'y';
}

static void motor_task()
{
    reset_values();
    while(1)
    {
        read_motor_values();
        calc_odom();
        // ESP_LOGI(TAG,"%f %f %f %f", left_motor_dist, left_motor_vel, right_motor_dist, right_motor_vel);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

esp_err_t motor_control_init(void)
{
    esp_err_t ret;
    
    uart_config_t uart_config = {
        .baud_rate = BAUD_RATE,
        .parity = PARITY,
        .stop_bits = STOP_BITS,
        .data_bits = DATA_BITS,
        .flow_ctrl = FLOW_CONTROL,
        .source_clk = SOURCE_CLOCK
    };
    
    uart_driver_install(UART_NUM_0, 1024, 1024, 0, NULL, 0);
    uart_param_config(UART_NUM_0, &uart_config);
    ret = uart_set_pin(UART_NUM_0, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    
    xTaskCreate(motor_task, "motor_task", 4096, NULL, 10, NULL);
    
    return ret;
}