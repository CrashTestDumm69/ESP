#ifndef MOTOR_CONTROL_H_
#define MOTOR_CONTROL_H_

#pragma once

#include <string.h>
#include <math.h>

#include "esp_log.h"
#include "esp_system.h"
#include "esp_err.h"
#include "esp_timer.h"

#include "driver/uart.h"
#include "driver/gpio.h"

#define BAUD_RATE       115200
#define DATA_BITS       UART_DATA_8_BITS
#define PARITY          UART_PARITY_DISABLE
#define STOP_BITS       UART_STOP_BITS_1
#define FLOW_CONTROL    UART_HW_FLOWCTRL_DISABLE
#define SOURCE_CLOCK    UART_SCLK_DEFAULT

#define RADIUS          0.05
#define WHEELBASE       0.3
#define STOP_LIMIT      15

#define PI              3.1415926535897932384626433832795             
#define P180            PI / 180

struct motor
{
  int vel;
  int pos;
};

float get_left_motor_dist();

float get_right_motor_dist();

float get_left_motor_vel();

float get_right_motor_vel();

float get_odom_x();

float get_odom_y();

float get_odom_theta();

float get_linear_vel();

float get_angular_vel();

void set_stop_flag();

void set_brakes();

esp_err_t motor_control_init(void);

void move_robot(float lin_v, float ang_v);

void set_vel(uint8_t id, int vel, uint8_t acc);

void reset_values();


#endif // MOTOR_CONTROL_H_