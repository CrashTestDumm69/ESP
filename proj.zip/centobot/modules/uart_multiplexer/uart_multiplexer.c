#include "uart_multiplexer.h"

esp_err_t uart_init(void)
{
    uart_config_t uart_config = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT
    };
    
    uart_driver_install(UART_NUM_1, RX_DRIVER_BUFFER_SIZE * 2, 0, 0, NULL, 0);
    uart_param_config(UART_NUM_1, &uart_config);
    return(uart_set_pin(UART_NUM_1, TXD_PIN, RXD_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
}

esp_err_t multiplexer_init(void)
{
    esp_rom_gpio_pad_select_gpio(GPIO_NUM_45);
    gpio_set_direction(GPIO_NUM_45, GPIO_MODE_OUTPUT);

    switch_multiplexer(ULTRASONIC);
    
    return ESP_OK;
}

void switch_multiplexer(uart_devices device)
{
    gpio_set_level(GPIO_NUM_45, device);
}