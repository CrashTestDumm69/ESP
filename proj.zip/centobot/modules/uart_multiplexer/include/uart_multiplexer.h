#ifndef UART_MULTIPLEX_H_
#define UART_MULTIPLEX_H_

#pragma once

#include "driver/gpio.h"
#include "driver/uart.h"

#define TXD_PIN                 (GPIO_NUM_42)
#define RXD_PIN                 (GPIO_NUM_41)

#define RX_DRIVER_BUFFER_SIZE   1024     

#define QUEUE_SIZE              1

typedef enum uart_devices_e
{
    CHARGER,
    ULTRASONIC,
    UART_DEVICES_MAX
}uart_devices;

esp_err_t uart_init(void);

esp_err_t multiplexer_init(void);

void switch_multiplexer(uart_devices device);

#endif //UART_MULTIPLEX_H_