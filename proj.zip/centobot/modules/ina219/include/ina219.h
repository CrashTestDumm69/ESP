#ifndef INA219_H_
#define INA219_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "i2c_sensor.h"

#define INA219_ADDR                         0x40

#define CONFIG_REG                          0x00
#define SHUNTVOLTAGE_REG                    0x01
#define BUSVOLTAGE_REG                      0x02
#define POWER_REG                           0x03
#define CURRENT_REG                         0x04
#define CALIBRATION_REG                     0x05

#define CFG_BVOLTRANGE_32V                  0x2000
#define CFG_GAIN_8_320MV                    0x1800
#define CFG_BADCRES_12BIT                   0x0180
#define CFG_SADCRES_12BIT_1S_532US          0x0018
#define CFG_MODE_SANDBVOLT_CONTINUOUS       0x07

#define CALIBRATION_VALUE_32V_2A            4096
#define CALIBRATION_VALUE_32V_1A            10240

float get_bus_voltage();

void read_bus_voltage();

esp_err_t ina219_init(void);

#endif // INA219_H_