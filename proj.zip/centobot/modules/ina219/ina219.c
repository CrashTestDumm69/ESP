#include "ina219.h"

#define TAG "INA219"

static int cur_divider_mA = 0;
static float power_multiplier_mW = 0.f;

static float voltage = 0.f;

float get_bus_voltage()
{
    return voltage;
}

void read_bus_voltage()
{
    uint16_t val;
    uint8_t buffer[2];
    i2c_master_register_read(INA219_ADDR, BUSVOLTAGE_REG, buffer, 2);
    val = buffer[0];
    val <<= 8;
    val |= buffer[1];
    voltage = (int16_t)((val >> 3) * 4) * 0.001f;
}

static void set_calibration_32V_1A()
{
    cur_divider_mA = 25;            // Current LSB = 40uA per bit
    power_multiplier_mW = 0.8f;     // Power LSB = 800uW per bit

    uint32_t val = CALIBRATION_VALUE_32V_1A;

    uint8_t buffer[2];

    buffer[1] = val & 0xFF;
    val >>= 8;
    buffer[0] = val & 0xFF;
    i2c_master_register_write(INA219_ADDR, CALIBRATION_REG, buffer, 2);

    uint16_t cfg = CFG_BVOLTRANGE_32V | CFG_GAIN_8_320MV | CFG_BADCRES_12BIT | CFG_SADCRES_12BIT_1S_532US | CFG_MODE_SANDBVOLT_CONTINUOUS;

    val = (uint32_t)cfg;

    buffer[1] = val & 0xFF;
    val >>= 8;
    buffer[0] = val & 0xFF;
    i2c_master_register_write(INA219_ADDR, CALIBRATION_REG, buffer, 2);
}

static void set_calibration_32V_2A()
{
    cur_divider_mA = 10;        // Current LSB = 100uA per bit
    power_multiplier_mW = 2;    // Power LSB = 1mW per bit

    uint32_t val = CALIBRATION_VALUE_32V_2A;

    uint8_t buffer[2];

    buffer[1] = val & 0xFF;
    val >>= 8;
    buffer[0] = val & 0xFF;
    i2c_master_register_write(INA219_ADDR, CALIBRATION_REG, buffer, 2);

    uint16_t cfg = CFG_BVOLTRANGE_32V | CFG_GAIN_8_320MV | CFG_BADCRES_12BIT | CFG_SADCRES_12BIT_1S_532US | CFG_MODE_SANDBVOLT_CONTINUOUS;

    val = (uint32_t)cfg;

    buffer[1] = val & 0xFF;
    val >>= 8;
    buffer[0] = val & 0xFF;
    i2c_master_register_write(INA219_ADDR, CALIBRATION_REG, buffer, 2);
}

esp_err_t ina219_init(void)
{
    // Set calibration to 32V 2A to start
    set_calibration_32V_2A();

    set_calibration_32V_1A();
    return ESP_OK;
}