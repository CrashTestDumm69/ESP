#include "status_led.h"

static led_strip_handle_t led_strip;

static led_state state = IDLE;

static void blink()
{
    int i, j;
    while(1)
    {
        switch(state)
        {
            case IDLE:
                for(j = 0 ; j < 3 ; j++)
                {    
                    for(i = 0 ; i < 256 ; i+=2)
                    {
                        led_strip_set_pixel(led_strip, j, 0, 0, i);
                        led_strip_refresh(led_strip);
                        vTaskDelay(pdMS_TO_TICKS(5));
                    }
                }

                for(j = 0 ; j < 3 ; j++)
                {    
                    for(i = 255 ; i >= 0 ; i-=2)
                    {
                        led_strip_set_pixel(led_strip, j, 0, 0, i);
                        led_strip_refresh(led_strip);
                        vTaskDelay(pdMS_TO_TICKS(5));
                    }
                }
                break;
            
            case INTERACTING:
                for(j = 0 ; j < 3 ; j++)
                {
                    for(i = 0 ; i < 256 ; i++)
                    {
                        led_strip_set_pixel(led_strip, j, i, 0, i);
                        led_strip_refresh(led_strip);
                        vTaskDelay(pdMS_TO_TICKS(5));
                    }
                }
                for(j = 0 ; j < 3 ; j++)
                { 
                    for(i = 255;i >= 0; i--)
                    {
                        led_strip_set_pixel(led_strip, j, i, 0, i);
                        led_strip_refresh(led_strip);
                        vTaskDelay(pdMS_TO_TICKS(5));
                    }
                }
                break;
            default:
                break;
        }
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

void select_status(led_state sel)
{
    state = sel;
}

esp_err_t status_led_init(void)
{
    esp_err_t ret;
    
    led_strip_config_t strip_config = {
        .strip_gpio_num = LED_PIN,
        .max_leds = LED_COUNT,
    };
    
    led_strip_rmt_config_t rmt_config = {
        .resolution_hz = RMT_RESOLUTION, // 10MHz
    };
    
    ret = led_strip_new_rmt_device(&strip_config, &rmt_config, &led_strip);
    led_strip_clear(led_strip);
    
    xTaskCreate(blink, "blink_task", 4096, NULL, 5, NULL);
    
    return ret;
}