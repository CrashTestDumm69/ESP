#ifndef STATES_H_
#define STATES_H_

#pragma once

typedef enum led_states_e
{
    IDLE,
    INTERACTING,
    CHARGING,
    LED_STATE_MAX
}led_state;

#endif //STATES_H_