#ifndef LIGHT_STATUS_H_
#define LIGHT_STATUS_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "led_strip.h"

#include "states.h"

#define LED_PIN         (GPIO_NUM_40)
#define LED_COUNT       3
#define RMT_RESOLUTION  (10 * 1000 * 1000)

void select_status(led_state sel);

esp_err_t status_led_init(void);


#endif //LIGHT_STATUS_H_