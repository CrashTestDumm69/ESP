#ifndef VL53L0X_H_
#define VL53L0X_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "i2c_sensor.h"

#define VL53L0X_ADDR                                    0x29

#define SYSRANGE_START_REG                 		        0x0000
#define RANGE_CFG_REG               			        0x0009
#define RESULT_RANGE_STATUS_REG            		        0x0014
#define MODEL_ID_REG                                    0x00C0
#define REVISION_ID_REG                           		0x00C2
#define VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV_REG           0x0089
#define I2C_SLAVE_DEVICE_ADDRESS_REG                	0x008A

#define VAL_HIGH_PRECISON_DISABLE                       0x00
#define VAL_HIGH_PRECISON_ENABLE                        0x01
#define VAL_CONTINUOUS_MODE                             0x0002

esp_err_t vl53l0x_init(void);

void read_cliff_distance();

float get_cliff_distance(void);

#endif // VL53L0X_H_