#include "vl53l0x.h"

#define TAG "VL53L0X"

static bool precision = true;

static uint16_t _dist;

static const uint8_t b_0 = 0x00;
static const uint8_t b_1 = 0x01;
static const uint8_t b_3C = 0x3C;

static float distance;

float get_cliff_distance()
{
    return distance;
}

void read_cliff_distance()
{
    uint8_t data[12];
    i2c_master_register_read(VL53L0X_ADDR, RESULT_RANGE_STATUS_REG, data, 12);
    uint16_t dist = (data[10] & 0xFF) << 8 | (data[11] & 0xFF);
    if(dist == 20)
    {
        dist = _dist;
    }
    else
    {
        _dist = dist;
    }
    if(precision)
    {
        distance = (float)(dist / 4.f);
    }
    else
    {
        distance = (float)dist;
    }
}

static void start()
{
    i2c_master_register_write(VL53L0X_ADDR, 0x80, &b_1, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0xFF, &b_1, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x00, &b_0, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x91, &b_3C, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x00, &b_1, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0xFF, &b_0, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x80, &b_0, 1);

    uint8_t data = VAL_CONTINUOUS_MODE;
    i2c_master_register_write(VL53L0X_ADDR, SYSRANGE_START_REG, &data, 1);
}

static void set_mode()
{
    uint8_t data;
    if(precision)
    {
        data = VAL_HIGH_PRECISON_ENABLE;
    }
    else
    {
        data = VAL_HIGH_PRECISON_DISABLE;
    }
    i2c_master_register_write(VL53L0X_ADDR, RANGE_CFG_REG, &data, 1);
}

esp_err_t vl53l0x_init(void)
{
    uint8_t data;
    vTaskDelay(pdMS_TO_TICKS(1500));
    i2c_master_register_read(VL53L0X_ADDR, VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV_REG, &data, 1);
    data = (data & 0xFE) | 0x01;
    i2c_master_register_write(VL53L0X_ADDR, VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV_REG, &data, 1);

     
    i2c_master_register_write(VL53L0X_ADDR, 0x88, &b_0, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x80, &b_1, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0xFF, &b_1, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x00, &b_0, 1);

    i2c_master_register_read(VL53L0X_ADDR, 0x91, &data, 1);
    
    i2c_master_register_write(VL53L0X_ADDR, 0x91, &b_3C, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x00, &b_1, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0xFF, &b_0, 1);
    i2c_master_register_write(VL53L0X_ADDR, 0x80, &b_0, 1);

    data = VL53L0X_ADDR & 0x7F;
    i2c_master_register_write(VL53L0X_ADDR, I2C_SLAVE_DEVICE_ADDRESS_REG, &data, 1);

    i2c_master_register_read(VL53L0X_ADDR, REVISION_ID_REG, &data, 1);
    ESP_LOGI(TAG, "Revision ID - 0x%2x", data);
    i2c_master_register_read(VL53L0X_ADDR, MODEL_ID_REG, &data, 1);
    ESP_LOGI(TAG, "Model ID - 0x%2x", data);

    set_mode();
    start();
    
    return ESP_OK;
}