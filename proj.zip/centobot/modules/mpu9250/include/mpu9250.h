#ifndef MPU9250_H_
#define MPU9250_H_

#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"

#include "i2c_sensor.h"

#define MPU9250_ADDR                0x68

#define WHO_AM_I_REG                0x75
#define PWR_MGMT_1_REG              0x6B
#define INT_PIN_CFG_REG             0x37
#define CFG_REG                     0x1A
#define GYRO_CFG_REG                0x1B
#define ACC_CFG_REG                 0x1C
#define ACC_CFG_2_REG               0x1D
#define SMPLRT_DIV_REG              0x19

#define ACCEL_XOUT_H                0x3B
#define GYRO_XOUT_H                 0x43

#define NUM_SAMPLES                 1000

#define ACCEL_SENSITIVITY           16384.0f        // Sensitivity for ±2g range (LSB/g)
#define GYRO_SENSITIVITY            32768.0f        // Sensitivity for ±250 degrees/sec range (LSB/(°/sec))

void read_mpu9250_data();

float get_gyro_x();
float get_gyro_y();
float get_gyro_z();
float get_accel_x();
float get_accel_y();
float get_accel_z();

esp_err_t mpu9250_init(void);

#endif // MPU9250_H_