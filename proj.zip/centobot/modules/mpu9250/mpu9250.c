#include "mpu9250.h"

#define TAG "MPU9250"

static uint8_t reg_val_reset = 0x80;
static uint8_t reg_val_bypass_en = 0x02;
static uint8_t reg_val_who_am_i = 0x71;

static float acc_bias[3] = {0.0, 0.0, 0.0};
static float gyro_bias[3] = {0.0, 0.0, 0.0};

static float acc_x = 0.f;
static float acc_y = 0.f; 
static float acc_z = 0.f;

static float gyro_x = 0.f;
static float gyro_y = 0.f;
static float gyro_z = 0.f;

static uint8_t acc_range_factor;
static uint8_t gyro_range_factor;

static void set_sample_rate_divider(uint8_t div)
{
    i2c_master_register_write(MPU9250_ADDR, SMPLRT_DIV_REG, &div, 1);
}

static void auto_offsets()
{
    uint8_t val;
    
    // Enable gyroscope DLPF
    i2c_master_register_read(MPU9250_ADDR, GYRO_CFG_REG, &val, 1);
    val &= 0xFC;
    i2c_master_register_write(MPU9250_ADDR, GYRO_CFG_REG, &val, 1);

    // Set gyro DLPF as DLPF 6 (0 - 7 for DLFP 0 - 7)
    i2c_master_register_read(MPU9250_ADDR, CFG_REG, &val, 1);
    val &= 0xF8;
    val |= 6;
    i2c_master_register_write(MPU9250_ADDR, CFG_REG, &val, 1);

    // Set gyro range 250 (0 for range 250, 1 for range 500, 2 for range 1000, 3 for range 2000)
    i2c_master_register_read(MPU9250_ADDR, GYRO_CFG_REG, &val, 1);
    val &= 0xE7;
    val |= (0 << 3);
    i2c_master_register_write(MPU9250_ADDR, GYRO_CFG_REG, &val, 1);
    gyro_range_factor = (1 << 0);

    // Set accelerometer range 2g (0 for 2g, 1 for 4g, 2 for 8g, 3 for 16g)
    i2c_master_register_read(MPU9250_ADDR, ACC_CFG_REG, &val, 1);
    val &= 0xE7;
    val |= (0 << 3);
    i2c_master_register_write(MPU9250_ADDR, ACC_CFG_REG, &val, 1);
    acc_range_factor = (1 << 0);

    // Enable accelerometer DLPF
    i2c_master_register_read(MPU9250_ADDR, ACC_CFG_2_REG, &val, 1);
    val &= ~8;
    i2c_master_register_write(MPU9250_ADDR, ACC_CFG_2_REG, &val, 1);

    // Set accelerometer DLPF to DLPF 6
    i2c_master_register_read(MPU9250_ADDR, ACC_CFG_2_REG, &val, 1);
    val &= 0xF8;
    val |= 6;
    i2c_master_register_write(MPU9250_ADDR, ACC_CFG_2_REG, &val, 1);

    vTaskDelay(pdMS_TO_TICKS(100));

    float acc_bias_sum[3] = {0.f};
    float gyro_bias_sum[3] = {0.f};

    for (int i = 0; i < NUM_SAMPLES; i++)
    {
        uint8_t sensor_data[6];

        // Read accelerometer data
        if (i2c_master_register_read(MPU9250_ADDR, ACCEL_XOUT_H, sensor_data, 6) != ESP_OK)
        {
            ESP_LOGI(TAG, "Failed to read accelerometer data\n");
            return;
        }

        int16_t acc_raw[3];
        acc_raw[0] = (int16_t)((sensor_data[0] << 8) | sensor_data[1]);
        acc_raw[1] = (int16_t)((sensor_data[2] << 8) | sensor_data[3]);
        acc_raw[2] = (int16_t)((sensor_data[4] << 8) | sensor_data[5]);

        acc_bias_sum[0] += (float)acc_raw[0];
        acc_bias_sum[1] += (float)acc_raw[1];
        acc_bias_sum[2] += (float)acc_raw[2];

        // Read gyroscope data
        if (i2c_master_register_read(MPU9250_ADDR, GYRO_XOUT_H, sensor_data, 6) != ESP_OK)
        {
            ESP_LOGI(TAG, "Failed to read gyroscope data\n");
            return;
        }

        int16_t gyro_raw[3];
        gyro_raw[0] = (int16_t)((sensor_data[0] << 8) | sensor_data[1]);
        gyro_raw[1] = (int16_t)((sensor_data[2] << 8) | sensor_data[3]);
        gyro_raw[2] = (int16_t)((sensor_data[4] << 8) | sensor_data[5]);

        gyro_bias_sum[0] += (float)gyro_raw[0];
        gyro_bias_sum[1] += (float)gyro_raw[1];
        gyro_bias_sum[2] += (float)gyro_raw[2];

        vTaskDelay(pdMS_TO_TICKS(1));
    }
    acc_bias[0] = acc_bias_sum[0] / NUM_SAMPLES;
    acc_bias[1] = acc_bias_sum[1] / NUM_SAMPLES;
    acc_bias[2] = acc_bias_sum[2] / NUM_SAMPLES;

    acc_bias[2] -= ACCEL_SENSITIVITY;

    gyro_bias[0] = gyro_bias_sum[0] / NUM_SAMPLES;
    gyro_bias[1] = gyro_bias_sum[1] / NUM_SAMPLES;
    gyro_bias[2] = gyro_bias_sum[2] / NUM_SAMPLES;
}

float get_gyro_x()
{
    return gyro_x;
}

float get_gyro_y()
{
    return gyro_y;
}

float get_gyro_z()
{
    return gyro_z;
}

float get_accel_x()
{
    return acc_x;
}

float get_accel_y()
{
    return acc_y;
}

float get_accel_z()
{
    return acc_z;
}

void read_mpu9250_data()
{
    uint8_t sensor_data[6];

    // Read accelerometer data
    if (i2c_master_register_read(MPU9250_ADDR, ACCEL_XOUT_H, sensor_data, 6) != ESP_OK) {
        ESP_LOGI(TAG, "Failed to read accelerometer data\n");
        return;
    }

    int16_t acc_raw[3];
    acc_raw[0] = (int16_t)((sensor_data[0] << 8) | sensor_data[1]);
    acc_raw[1] = (int16_t)((sensor_data[2] << 8) | sensor_data[3]);
    acc_raw[2] = (int16_t)((sensor_data[4] << 8) | sensor_data[5]);

    acc_x = (float)acc_raw[0];
    acc_y = (float)acc_raw[1];
    acc_z = (float)acc_raw[2];

    acc_x -= (acc_bias[0] / acc_range_factor);
    acc_y -= (acc_bias[1] / acc_range_factor);
    acc_z -= (acc_bias[2] / acc_range_factor);

    acc_x *= ((float)acc_range_factor / ACCEL_SENSITIVITY) * 9.80665f;
    acc_y *= ((float)acc_range_factor / ACCEL_SENSITIVITY) * 9.80665f;
    acc_z *= ((float)acc_range_factor / ACCEL_SENSITIVITY) * 9.80665f;

    // Read gyroscope data
    if (i2c_master_register_read(MPU9250_ADDR, GYRO_XOUT_H, sensor_data, 6) != ESP_OK)
    {
        ESP_LOGI(TAG, "Failed to read gyroscope data\n");
        return;
    }

    int16_t gyro_raw[3];
    gyro_raw[0] = (int16_t)((sensor_data[0] << 8) | sensor_data[1]);
    gyro_raw[1] = (int16_t)((sensor_data[2] << 8) | sensor_data[3]);
    gyro_raw[2] = (int16_t)((sensor_data[4] << 8) | sensor_data[5]);

    gyro_x = (float)gyro_raw[0];
    gyro_y = (float)gyro_raw[1];
    gyro_z = (float)gyro_raw[2];

    gyro_x -= (gyro_bias[0] / gyro_range_factor);
    gyro_y -= (gyro_bias[1] / gyro_range_factor);
    gyro_z -= (gyro_bias[2] / gyro_range_factor);

    gyro_x *= (((float)gyro_range_factor * 250.f) / GYRO_SENSITIVITY) * 0.0174533f;
    gyro_y *= (((float)gyro_range_factor * 250.f) / GYRO_SENSITIVITY) * 0.0174533f;
    gyro_z *= (((float)gyro_range_factor * 250.f) / GYRO_SENSITIVITY) * 0.0174533f;
}

esp_err_t mpu9250_init(void)
{
    uint8_t val;
    
    // Reset MPU9250
    i2c_master_register_write(MPU9250_ADDR, PWR_MGMT_1_REG, &reg_val_reset, 1);
    vTaskDelay(pdMS_TO_TICKS(21));
    
    // Check if MPU can be read
    i2c_master_register_write(MPU9250_ADDR, INT_PIN_CFG_REG, &reg_val_bypass_en, 1);
    vTaskDelay(pdMS_TO_TICKS(11));
    i2c_master_register_read(MPU9250_ADDR, WHO_AM_I_REG, &val, 1);
    if(val != reg_val_who_am_i)
    {
        return 0;
    }

    acc_bias[0] = 0;
    acc_bias[1] = 0;
    acc_bias[2] = 0;
    acc_range_factor = 1;
    gyro_bias[0] = 0;
    gyro_bias[1] = 0;
    gyro_bias[2] = 0;
    gyro_range_factor = 1;


    // Sleep
    i2c_master_register_read(MPU9250_ADDR, PWR_MGMT_1_REG, &val, 1);
    val &= ~0x40;
    i2c_master_register_write(MPU9250_ADDR, PWR_MGMT_1_REG, &val, 1);
    
    ESP_LOGI(TAG, "Calibrating MPU9250.....");

    auto_offsets();
    set_sample_rate_divider(5);

    return ESP_OK;
}