#ifndef I2C_SENSOR_H_
#define I2C_SENSOR_H_

#pragma once

#include "esp_log.h"
#include "esp_err.h"

#include "driver/i2c.h"

#define I2C_MASTER_SCL_IO           2               // GPIO number used for I2C master clock
#define I2C_MASTER_SDA_IO           3               // GPIO number used for I2C master data 
#define I2C_MASTER_PORT_NUM         I2C_NUM_0       // I2C master i2c port number
#define I2C_MASTER_FREQ_HZ          100000          // I2C master clock frequency
#define I2C_MASTER_TX_BUF_DISABLE   0               // I2C master doesn't need buffer
#define I2C_MASTER_RX_BUF_DISABLE   0               // I2C master doesn't need buffer

esp_err_t i2c_master_init(void);

esp_err_t i2c_master_register_write(uint8_t slave_addr, uint8_t reg_addr, uint8_t* data_wr, size_t size);

esp_err_t i2c_master_register_read(uint8_t slave_addr, uint8_t reg_addr, uint8_t* data_rd, size_t size);

esp_err_t i2c_master_device_write(uint8_t slave_addr, uint8_t* data_wr, size_t size);

esp_err_t i2c_master_device_read(uint8_t slave_addr, uint8_t* data_rd, size_t size);

#endif // I2C_SENSOR_H_